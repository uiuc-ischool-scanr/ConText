var item_count = 5;
var word_per_item = 5;
var width = 1000,
    height = 1000,
	fontSize = 20;

			var wordList = [
	{text: "Juan",topic:2,sentiment:2,frequency:27,fitVal:0.2},
	{text: "Marin",topic:2,sentiment:2,frequency:26,fitVal:0.2},
	{text: "JUAN",topic:1,sentiment:2,frequency:25,fitVal:0.2},
	{text: "MARIN",topic:1,sentiment:2,frequency:24,fitVal:0.2},
	{text: "BERGMAN",topic:4,sentiment:2,frequency:24,fitVal:0.2},
	{text: "women",topic:0,sentiment:2,frequency:23,fitVal:0.2},
	{text: "TAMAYO",topic:3,sentiment:2,frequency:17,fitVal:0.2},
	{text: "RODRIGUEZ",topic:3,sentiment:2,frequency:16,fitVal:0.2},
	{text: "sexual",topic:0,sentiment:2,frequency:15,fitVal:0.2},
	{text: "don",topic:0,sentiment:2,frequency:15,fitVal:0.2},
	{text: "Maricruz",topic:1,sentiment:2,frequency:15,fitVal:0.2},
	{text: "case",topic:2,sentiment:2,frequency:15,fitVal:0.2},
	{text: "Schultz",topic:0,sentiment:2,frequency:14,fitVal:0.2},
	{text: "WOMEN",topic:1,sentiment:2,frequency:14,fitVal:0.2},
	{text: "harassment",topic:0,sentiment:-1,frequency:13,fitVal:0.2},
	{text: "CASE",topic:1,sentiment:2,frequency:13,fitVal:0.2},
	{text: "told",topic:2,sentiment:2,frequency:12,fitVal:0.2},
	{text: "MARICRUZ",topic:3,sentiment:2,frequency:12,fitVal:0.2},
	{text: "Paul",topic:4,sentiment:2,frequency:12,fitVal:0.2},
	{text: "DON",topic:2,sentiment:2,frequency:10,fitVal:0.2},
	{text: "SONIA",topic:4,sentiment:2,frequency:10,fitVal:0.2},
	{text: "FARM",topic:4,sentiment:2,frequency:9,fitVal:0.2},
	{text: "mas",topic:3,sentiment:2,frequency:8,fitVal:0.2},
	{text: "workers",topic:4,sentiment:2,frequency:8,fitVal:0.2},
	{text: "OLIVIA",topic:3,sentiment:2,frequency:7,fitVal:0.2},
];