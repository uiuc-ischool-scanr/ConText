var item_count = 5;
var width = 800,
    height = 1000,
	fontSize = 20;

var wordList = [
		{text: "Hello",topic:1,sentiment:1,frequency:10},
		{text: "world",topic:1,sentiment:1,frequency:20},
		{text: "normally",topic:2,sentiment:1,frequency:10},
		{text: "you",topic:2,sentiment:-1,frequency:20},
		{text: "want",topic:2,sentiment:-1,frequency:30},
		{text: "more",topic:2,sentiment:2,frequency:10},
		{text: "words",topic:1,sentiment:1,frequency:10},
		{text: "than",topic:1,sentiment:0,frequency:10},
		{text: "this",topic:1,sentiment:-1,frequency:10},
		{text: "Hawking",topic:3,sentiment:1,frequency:10},
		{text: "Piko",topic:3,sentiment:1,frequency:22},
		{text: "New",topic:3,sentiment:1,frequency:10},
		{text: "False",topic:3,sentiment:1,frequency:12},
		{text: "awkward",topic:3,sentiment:1,frequency:10},
		{text: "bad",topic:4,sentiment:1,frequency:10},
		{text: "good",topic:4,sentiment:0,frequency:10},
		{text: "roam",topic:4,sentiment:-1,frequency:5},
		{text: "wander",topic:4,sentiment:1,frequency:10},
		{text: "love",topic:4,sentiment:1,frequency:4},
		{text: "sing",topic:2,sentiment:1,frequency:3},
		{text: "fly",topic:2,sentiment:0,frequency:10},
		{text: "teach",topic:5,sentiment:1,frequency:10},
		{text: "trim",topic:5,sentiment:0,frequency:30},
		{text: "run",topic:5,sentiment:2,frequency:25},
		{text: "sneak",topic:5,sentiment:1,frequency:10},
		{text: "combat",topic:5,sentiment:1,frequency:10}
		];
